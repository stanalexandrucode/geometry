package com.codecool.geometry;

import com.codecool.geometry.containers.ShapeCollection;
import com.codecool.geometry.shapes.Circle;
import com.codecool.geometry.shapes.Triangle;


public class Main {

    //    public static void main(String[] args) {
//
//        boolean isRunning = true;
//
//        while (isRunning) {
//            int option = 0;  // TODO read the keyboard here
//
//            switch (option) {
//                case 1:
//                    // TODO Add new shape
//                    break;
//                case 2:
//                    // TODO Show all shapes
//                    break;
//                case 3:
//                    // TODO Show shape with the largest perimeter
//                    break;
//                case 4:
//                    // TODO Show shape with the largest area
//                    break;
//                case 5:
//                    // TODO Show formulas
//                    break;
//                case 0:
//                    // TODO Exit
//                    break;
//            }
//        }
//    }
    public static void main(String[] args) {
        Triangle triangle = new Triangle(5, 4, 3, 8);
        Circle cerc = new Circle(5);
        ShapeCollection tata = new ShapeCollection();
        tata.addShape(triangle);
        tata.addShape(cerc);
        System.out.println(tata.getShapes());;
    }


}

