package com.codecool.geometry.shapes;

public class EquilateralTriangle extends Triangle {

    public EquilateralTriangle(int base, int lSide, int rSide, int height) {
        super(base, lSide, rSide, height);
    }

    @Override
    public String toString() {
        return String.format("Equilateral Triangle with: Base=%d,Left side=%d,Right side=%d,Height=%d",
                getBase(), getlSide(), getrSide(), getHeight());

    }
}
