package com.codecool.geometry.shapes;

public class Circle extends Shape {
    private int radiant;
    private final double pi = 3.14;

    public Circle(int radiant) {
        this.radiant = radiant;
    }

    @Override
    public double calculateArea() {

        return (pi * (Math.pow(radiant, 2)));
    }

    @Override
    public double calculatePerimeter() {

        return 2 * pi * radiant;
    }

    @Override
    public String toString() {
        return String.format("Cicle with: Radiant=%d", radiant);

    }


}
