package com.codecool.geometry.shapes;

public class Triangle extends Shape {
    private int base, lSide, rSide, height;

    public Triangle(int base, int lSide, int rSide, int height) {
        this.base = base;
        this.lSide = lSide;
        this.rSide = rSide;
        this.height = height;
    }

    @Override
    public double calculateArea() {
        return (base * height) / 2;

    }

    @Override
    public double calculatePerimeter() {

        return base + lSide + rSide;
    }


    @Override
    public String toString() {
        return String.format("Triangle with: Base=%d,Left side=%d,Right side=%d,Height=%d", base, lSide, rSide, height);

    }

    public int getBase() {
        return base;
    }

    public int getlSide() {
        return lSide;
    }

    public int getrSide() {
        return rSide;
    }

    public int getHeight() {
        return height;
    }
}
