package com.codecool.geometry.containers;

import com.codecool.geometry.shapes.Shape;

import java.util.List;


public class ShapeCollection {
    private List<Shape> shapes;

    public ShapeCollection() {

    }

//    public ShapeCollection(List<Shape> shapes) {
//        this.shapes = shapes;
//    }

    public void addShape(Shape shape) {
        shapes.add(shape);
    }

//    public Shape getShapes() {
//        for (int i = 0; i < shapes.size(); i++) {
//            System.out.println(shapes.get(i));
//            return shapes.get(i);
//        }
//
//    }

    public List<Shape> getShapes() {
        return shapes;
    }
}
